
# Task 19 — Monte Carlo Simulation

Monte Carlo workloads are highly parallel because independent samples
can be processed separately.

Non-zero serial overhead comes from random-number seed management,
combining partial results, and writing output.

A tree reduction combines results in approximately O(log P) stages.
This overhead can reduce ideal speedup, especially at large P.
