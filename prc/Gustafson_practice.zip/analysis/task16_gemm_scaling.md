# Task 16 — Dense Matrix Multiplication

Student: Yerassyl Orazgali
ID: 230103272

GEMM computational complexity:

O(N^3)

Memory requirement:

O(N^2)

For weak scaling:

N^3 proportional to P

Therefore:

N proportional to P^(1/3)

Memory grows proportionally to P^(2/3).

Communication and memory bandwidth can still
limit performance.
