
# Task 20 — Graph Processing

BFS and PageRank are difficult to scale because graph connections
are irregular. Processors may receive unequal amounts of work.

Random memory access, synchronization, communication, and changing
frontier sizes create overhead.

Dense matrix operations usually have more regular memory access
and predictable work distribution, so they are often easier to scale.
