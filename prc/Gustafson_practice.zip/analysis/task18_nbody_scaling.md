
# Task 18 — N-Body Simulation

The direct method performs O(N^2) pair interactions.
The Barnes-Hut method reduces the approximate complexity to O(N log N).

When N grows with P, the direct method can become expensive very quickly.
Barnes-Hut reduces the growth rate, although tree construction and
communication introduce additional overhead.

The serial-to-parallel ratio depends on the implementation and
distribution of particles.
