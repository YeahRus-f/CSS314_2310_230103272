# Task 17 — 3D Stencil

Student: Yerassyl Orazgali
ID: 230103272

Interior computation:

O(N^3)

Boundary communication:

O(N^2)

Communication/computation ratio:

O(1/N)

If global volume scales proportionally to P,
global dimension grows as P^(1/3).

The global surface-to-volume ratio decreases
as P^(-1/3).

With fixed local subdomain size, each node's
local surface-to-volume ratio remains approximately
constant.
