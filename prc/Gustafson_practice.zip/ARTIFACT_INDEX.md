# Artifact Index

Yerassyl Orazgali
230103272

## theory
- theory/task01_scaling_models.md
- theory/task02_derivation.md
- theory/task03_serial_invariance.md
- theory/task04_asymptotic_limits.md
- theory/task05_historical_ncube.md
- theory/task11_sun_ni_comparison.md
- theory/task12_communication_penalty.md
- theory/task13_failure_cases.md
- theory/task14_isoefficiency.md
- theory/task15_energy_scaling.md

## calculations
- calculations/task06_parametric_table.md
- calculations/task07_tolerable_serial.md
- calculations/task08_cross_divergence.md
- calculations/task09_multicomponent.md
- calculations/task10_memory_growth.md

## benchmarks
- benchmarks/empirical_speedup.csv
- benchmarks/fit_gustafson.py
- benchmarks/results.csv
- benchmarks/simulator_output.csv

## analysis
- analysis/task16_gemm_scaling.md
- analysis/task17_stencil_scaling.md
- analysis/task18_nbody_scaling.md
- analysis/task19_monte_carlo.md
- analysis/task20_graph_processing.md
- analysis/task24_hardware_audit.md

## plots
- plots/task21_scaling_simulator.png
- plots/task24_empirical_comparison.png
