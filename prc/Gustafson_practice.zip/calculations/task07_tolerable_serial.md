# Task 07

alpha_max = (P - S) / (P - 1)

alpha_max = (8192 - 7500) / 8191 = **0.084483**