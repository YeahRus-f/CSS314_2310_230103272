
# Task 16 — Matrix Multiplication

For dense matrix multiplication, work is O(N^3).

Under weak scaling, total work grows proportionally to P:

N^3(P) = P * N^3(1)

Taking the cube root:

**N(P) = N(1) * P^(1/3)**

The matrix dimension grows with the cube root of processor count.
