
# Task 17 — 3D Stencil

Computation scales as O(N^3).
Boundary communication scales as O(N^2).

The communication-to-computation ratio is:

N^2 / N^3 = 1/N

If total domain volume grows proportionally to P,
then N grows as P^(1/3). The ratio therefore decreases as P^(-1/3),
assuming a cubic domain and comparable partitioning.
