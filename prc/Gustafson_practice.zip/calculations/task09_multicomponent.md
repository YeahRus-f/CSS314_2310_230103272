
# Task 09 — Multi-Component Workload

Serial and synchronization overhead:

alpha = 0.02 + 0.06 = 0.08

For P = 512:
S(P) = 512 - 0.08(511) = 471.12

For P = 2048:
S(P) = 2048 - 0.08(2047) = 1884.24
