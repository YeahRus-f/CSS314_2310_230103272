
# Task 10 — Memory Growth

Assumption: each node has 32 GB and each grid cell uses 8 bytes.

64 nodes: total memory = 64 * 32 GB = 2048 GB.
512 nodes: total memory = 512 * 32 GB = 16384 GB.

For a 3D grid, memory is proportional to N^3.
Thus N is proportional to the cube root of total memory.

Exact N cannot be determined without the constant memory
requirement per grid cell and any additional storage overhead.
