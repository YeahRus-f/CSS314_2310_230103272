# Task 08

Amdahl speedup = **11.4695**

Gustafson speedup = **117.8400**

Percentage difference relative to Amdahl = **927.42%**