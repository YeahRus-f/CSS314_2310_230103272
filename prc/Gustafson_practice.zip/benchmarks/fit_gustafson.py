
# Regression formula used in the main Colab notebook:
# S(P) = P - alpha(P - 1)
# alpha = sum((P-1)*(P-S)) / sum((P-1)^2)
