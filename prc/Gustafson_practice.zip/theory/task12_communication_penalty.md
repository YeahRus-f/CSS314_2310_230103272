
# Communication Penalty Model

A modified model can include communication overhead C(P):

S(P) = P - alpha(P-1) - C(P)

For example, communication may grow as:

C(P) = beta log2(P)

or C(P) = beta sqrt(P), where beta describes communication cost.

The effective speedup is reduced by communication. Therefore, a
real system may scale worse than the ideal Gustafson model.
