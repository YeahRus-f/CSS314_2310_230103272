
# Asymptotic Parallel Efficiency

Gustafson efficiency:

E(P) = S(P)/P = 1 - alpha + alpha/P

When P approaches infinity:

**lim E(P) = 1 - alpha**

Amdahl speedup approaches 1/s, while efficiency is S(P)/P.
Therefore, Amdahl efficiency approaches zero as P approaches infinity.

Gustafson efficiency remains positive when alpha is less than 1.
