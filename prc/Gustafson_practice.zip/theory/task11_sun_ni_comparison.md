
# Sun-Ni Memory-Bounded Speedup

Gustafson's Law assumes that workload grows with processor count.
The Sun-Ni model additionally considers available memory capacity.

If memory grows with the system, larger workloads can be processed.
If memory is limited, the expected workload expansion may be impossible.

Gustafson can overestimate throughput when memory, communication,
or synchronization becomes a bottleneck. It can underestimate it
when additional memory enables more work than assumed.
