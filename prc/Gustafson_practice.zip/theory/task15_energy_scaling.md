
# Energy and Power

Energy is power multiplied by time:

E = Power * Time

For one processor, energy is approximately:

E1 = (Pidle + Pactive) * T

For P processors, a simplified model is:

EP = P * (Pidle + Pactive) * T

At identical runtime, total energy may increase with processor count.
Actual energy depends on utilization, idle power, and hardware design.
