
# Isoefficiency and Weak Scaling

Isoefficiency describes how quickly problem size must grow with
processor count to maintain a fixed parallel efficiency.

For an ideal weak-scaling program, each processor receives a constant
amount of work. Total work therefore grows proportionally to P:

W(P) = P * W(1)

If communication and coordination remain bounded, efficiency can
remain approximately constant.
