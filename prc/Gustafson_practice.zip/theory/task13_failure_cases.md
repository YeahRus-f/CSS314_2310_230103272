
# When Gustafson's Law Fails

1. Breadth-First Search on irregular graphs:
   More processors do not guarantee balanced work. Some processors
   may wait for others, and communication increases.

2. All-pairs N-body simulation:
   Increasing particle count increases pair interactions quadratically.
   The computational cost may grow faster than available resources.

In both cases, constant execution time is difficult to maintain.
