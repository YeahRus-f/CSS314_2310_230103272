
# Derivation of Gustafson's Law

Let the parallel execution time be normalized:

s + p = 1

Here, s is the serial fraction and p is the parallel fraction.

On P processors, the equivalent sequential execution time is:

S(P) = s + Pp

Since p = 1 - s:

S(P) = s + P(1-s)
S(P) = P - s(P-1)

Using alpha for the serial fraction:

**S(P) = P - alpha(P-1)**
