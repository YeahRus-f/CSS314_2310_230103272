
# Amdahl's Law vs. Gustafson's Law

Amdahl's Law assumes a fixed problem size. Increasing the number of processors
reduces the parallel part, but the serial part remains unchanged. Therefore,
speedup has a theoretical limit of 1/s.

Gustafson's Law assumes that the problem size grows with the number of
processors while execution time remains approximately constant. This is
called weak scaling or fixed-time scaling.

Amdahl focuses on solving the same problem faster. Gustafson focuses on
solving larger problems in the same amount of time.
