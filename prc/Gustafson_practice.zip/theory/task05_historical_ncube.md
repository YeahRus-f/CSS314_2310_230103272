
# Historical nCUBE Example

The 1988 Gustafson, Montry and Benner work demonstrated that large
parallel systems could achieve very high speedups when the problem
size was expanded.

The reported experiment used a 1,024-processor nCUBE 10 system and
reported speedups exceeding 1,000. The key idea was to keep the
parallel execution time approximately constant while increasing
the amount of useful work.

This differs from Amdahl's fixed-size assumption.
