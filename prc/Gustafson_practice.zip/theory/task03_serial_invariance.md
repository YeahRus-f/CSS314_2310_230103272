
# Serial Fraction Invariance

Amdahl's Law measures the serial fraction relative to execution on one
processor. Gustafson's Law measures it on the parallel machine.

These measurements use different reference workloads. In weak scaling,
the parallel workload grows with processor count. The serial fraction
can remain small relative to the total parallel execution time.

Therefore, the two laws do not contradict each other: they describe
different scaling assumptions.
