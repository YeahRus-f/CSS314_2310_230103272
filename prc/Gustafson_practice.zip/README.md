
# Gustafson's Law Practice Project

**Student:** Yerassyl Orazgali  
**ID:** 230103272

## Project purpose

This project compares Amdahl's Law and Gustafson's Law,
calculates theoretical speedup, and measures multiprocessing
performance using a synthetic numerical workload.

## Main formulas

- Gustafson: S(P) = P - alpha(P - 1)
- Efficiency: E(P) = S(P) / P
- Amdahl: S(P) = 1 / (s + (1-s)/P)

## Folder structure

- theory/ — Tasks 01–05 and 11–15
- calculations/ — Tasks 06–10 and 16–17
- analysis/ — Tasks 18–20 and 24
- benchmarks/ — Tasks 21–23
- plots/ — generated figures

## Execution

Run the complete notebook in Google Colab.
The benchmark results are saved in benchmarks/results.csv.
The theoretical simulation is saved in benchmarks/simulator.csv.

## Conclusion

Amdahl's Law describes fixed-size scaling, while Gustafson's Law
describes weak scaling where the workload grows with processor count.
Real performance is affected by serial work, communication,
memory bandwidth, scheduling, and hardware limitations.
